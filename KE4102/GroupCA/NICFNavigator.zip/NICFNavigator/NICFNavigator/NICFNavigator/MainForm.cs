﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Mommosoft.ExpertSystem;
using System.Diagnostics;
using FlatUI;

namespace NicfNavigator {
    public partial class MainForm : System.Windows.Forms.Form {
        private Mommosoft.ExpertSystem.Environment _theEnv = new Mommosoft.ExpertSystem.Environment();
        public MainForm() {

            ConsoleTraceListener tl = new ConsoleTraceListener();
             InitializeComponent();
             _theEnv.AddRouter(new DebugRouter());
            _theEnv.Load("nicfnavigator.clp");
            _theEnv.Reset();
            
        }

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);
            NextUIState();
        }

        private void OnClickButton(object sender, EventArgs e) {
            FlatButton button = sender as FlatButton;
            // Get the state-list.
            String evalStr = "(find-all-facts ((?f state-list)) TRUE)";
            using (FactAddressValue f = (FactAddressValue)((MultifieldValue)_theEnv.Eval(evalStr))[0]) {
                string currentID = f.GetFactSlot("current").ToString();

                if (button.Tag.Equals("Next")) {
 
                    if (GetNoButton() == null) { _theEnv.AssertString("(next " + currentID + ")"); NextUIState(); }
                    else if(GetCheckedChoiceButton() != null)
                    {
                        _theEnv.AssertString("(next " + currentID + " " +
                                           (string)GetCheckedChoiceButton().Tag + ")");
                        NextUIState();
                    }
                    
                } else if (button.Tag.Equals("Restart")) {
                    _theEnv.Reset();
                    NextUIState();
                } else if (button.Tag.Equals("Prev")) {
                    _theEnv.AssertString("(prev " + currentID + ")");
                    NextUIState();
                }
            }
        }

        private void NextUIState() {
            nextButton.Visible = false;
            prevButton.Visible = false;
            choicesPanel.Controls.Clear();
            float certaintyValue = 0;

            //_theEnv.AssertString("(CF (candidate 0))"); 

            _theEnv.AssertString("(CF(candidate 0.0))");

            _theEnv.Run();
            //_theEnv.Watch(WatchItem.Facts);
            // Get the state-list.
            String evalStr = "(find-all-facts ((?f state-list)) TRUE)";
            using (FactAddressValue allFacts = (FactAddressValue)((MultifieldValue)_theEnv.Eval(evalStr))[0]) {
                string currentID = allFacts.GetFactSlot("current").ToString();
                evalStr = "(find-all-facts ((?f UI-state)) " +
                               "(eq ?f:id " + currentID + "))";
            }

            String evalCFStr = "(find-all-facts ((?f CF)) TRUE)";
            MultifieldValue mv = (MultifieldValue)_theEnv.Eval(evalCFStr);
            float evaluation = 0;
            using (FactAddressValue allFacts = (FactAddressValue)((MultifieldValue)_theEnv.Eval(evalCFStr))[0])
            {
                evaluation = float.Parse(allFacts.GetFactSlot("candidate").ToString());
            }
            string state;
            using (FactAddressValue evalFact = (FactAddressValue)((MultifieldValue)_theEnv.Eval(evalStr))[0]) {
                state = evalFact.GetFactSlot("state").ToString();
                if (state.Equals("initial")) {
                    nextButton.Visible = true;
                    nextButton.Tag = "Next";
                    nextButton.Text = "Start";
                    prevButton.Visible = false;
                    choicesPanel.Visible = false;
                } else if (state.Equals("final")) {
                    nextButton.Visible = true;
                    nextButton.Tag = "Restart";
                    nextButton.Text = "Restart";
                    prevButton.Visible = false;
                    choicesPanel.Visible = false;
                } else {
                    nextButton.Visible = true;
                    nextButton.Tag = "Next";
                    prevButton.Tag = "Prev";
                    nextButton.Text = "Next";
                    prevButton.Visible = false;
                    choicesPanel.Visible = true;
                }
                
                using (MultifieldValue validAnswers = (MultifieldValue)evalFact.GetFactSlot("valid-answers")) {
                    String selected = evalFact.GetFactSlot("response").ToString();
                    for (int i = 0; i < validAnswers.Count; i++) {
                        FlatRadioButton rb = new FlatRadioButton();
                        rb.Text = (SymbolValue)validAnswers[i];
                        rb.Tag =""+ (i+1);
                        rb.Visible = true;
                        rb.Location = new Point(10, 20 * (i + 1));
                        rb.Width = 400;
                        choicesPanel.Controls.Add(rb);
                    }
                }
                //  messageLabel.Text = evalFact.GetFactSlot("display").ToString().Replace("\"", "");
                using (MultifieldValue displayTextArry = (MultifieldValue)evalFact.GetFactSlot("display"))
                {
                    String displayTxt = "";
                    for (int i = 0; i < displayTextArry.Count; i++)
                    {
                        displayTxt = displayTxt + "\n" + displayTextArry[i].ToString().Replace("\"", "");
                        
                    }
                    if (state.Equals("initial"))
                        messageLabel.Text = displayTxt;
                    else
                    {
                        messageLabel.Text = displayTxt + "\n\n  Ability to assume the role : (" + (Math.Round(evaluation, 4) * 100) + "%)";
                    }
                }
                

            }
        }

        private void ShowChoices(bool visible) {
            foreach (System.Windows.Forms.Control control in choicesPanel.Controls) {
                control.Visible = visible;
            }
        }

        private FlatRadioButton GetNoButton()
        {
            foreach (FlatRadioButton control in choicesPanel.Controls)
            {
  
                    return control;
            }
            return null;
        }

        private FlatRadioButton GetCheckedChoiceButton() {
            foreach (FlatRadioButton control in choicesPanel.Controls) {
                if (control.Checked) {
                    return control;
                }
            }
            return null;
        }

        private string GetString(string name) {
            return SR.ResourceManager.GetString(name);
        }

        private void FormSkin_Click(object sender, EventArgs e)
        {

        }
    }
}
