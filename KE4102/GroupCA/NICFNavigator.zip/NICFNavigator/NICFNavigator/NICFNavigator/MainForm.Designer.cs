﻿namespace NicfNavigator {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FormSkin = new FlatUI.FormSkin();
            this.choicesPanel = new System.Windows.Forms.Panel();
            this.nextButton = new FlatUI.FlatButton();
            this.messageLabel = new FlatUI.FlatLabel();
            this.prevButton = new FlatUI.FlatButton();
            this.FlatMini = new FlatUI.FlatMini();
            this.FlatClose = new FlatUI.FlatClose();
            this.FormSkin.SuspendLayout();
            this.SuspendLayout();
            // 
            // FormSkin
            // 
            this.FormSkin.BackColor = System.Drawing.Color.White;
            this.FormSkin.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.FormSkin.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(58)))), ((int)(((byte)(60)))));
            this.FormSkin.Controls.Add(this.choicesPanel);
            this.FormSkin.Controls.Add(this.nextButton);
            this.FormSkin.Controls.Add(this.messageLabel);
            this.FormSkin.Controls.Add(this.prevButton);
            this.FormSkin.Controls.Add(this.FlatMini);
            this.FormSkin.Controls.Add(this.FlatClose);
            this.FormSkin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FormSkin.FlatColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.FormSkin.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.FormSkin.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.FormSkin.HeaderMaximize = false;
            this.FormSkin.Location = new System.Drawing.Point(0, 0);
            this.FormSkin.Margin = new System.Windows.Forms.Padding(6);
            this.FormSkin.Name = "FormSkin";
            this.FormSkin.Size = new System.Drawing.Size(1500, 1300);
            this.FormSkin.TabIndex = 0;
            this.FormSkin.Text = "NICF Cybersecurity Intelligent Navigator";
            this.FormSkin.Click += new System.EventHandler(this.FormSkin_Click);
            // 
            // choicesPanel
            // 
            this.choicesPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.choicesPanel.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.choicesPanel.Location = new System.Drawing.Point(408, 522);
            this.choicesPanel.Name = "choicesPanel";
            this.choicesPanel.Size = new System.Drawing.Size(607, 225);
            this.choicesPanel.TabIndex = 5;
            // 
            // nextButton
            // 
            this.nextButton.BackColor = System.Drawing.Color.Transparent;
            this.nextButton.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.nextButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nextButton.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.nextButton.Location = new System.Drawing.Point(577, 774);
            this.nextButton.Name = "nextButton";
            this.nextButton.Rounded = false;
            this.nextButton.Size = new System.Drawing.Size(247, 106);
            this.nextButton.TabIndex = 2;
            this.nextButton.Text = "&Next >";
            this.nextButton.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.nextButton.Click += new System.EventHandler(this.OnClickButton);
            // 
            // messageLabel
            // 
            this.messageLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.messageLabel.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messageLabel.ForeColor = System.Drawing.Color.White;
            this.messageLabel.Location = new System.Drawing.Point(78, 103);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(1237, 455);
            this.messageLabel.TabIndex = 0;
            this.messageLabel.Text = "label1";
            this.messageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // prevButton
            // 
            this.prevButton.BackColor = System.Drawing.Color.Transparent;
            this.prevButton.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(168)))), ((int)(((byte)(109)))));
            this.prevButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prevButton.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.prevButton.Location = new System.Drawing.Point(408, 818);
            this.prevButton.Name = "prevButton";
            this.prevButton.Rounded = false;
            this.prevButton.Size = new System.Drawing.Size(145, 57);
            this.prevButton.TabIndex = 1;
            this.prevButton.Text = "Previous";
            this.prevButton.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.prevButton.Click += new System.EventHandler(this.OnClickButton);
            // 
            // FlatMini
            // 
            this.FlatMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FlatMini.BackColor = System.Drawing.Color.White;
            this.FlatMini.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.FlatMini.Font = new System.Drawing.Font("Marlett", 12F);
            this.FlatMini.Location = new System.Drawing.Point(1406, 23);
            this.FlatMini.Margin = new System.Windows.Forms.Padding(6);
            this.FlatMini.Name = "FlatMini";
            this.FlatMini.Size = new System.Drawing.Size(18, 18);
            this.FlatMini.TabIndex = 5;
            this.FlatMini.Text = "Minimize";
            this.FlatMini.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // FlatClose
            // 
            this.FlatClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FlatClose.BackColor = System.Drawing.Color.White;
            this.FlatClose.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.FlatClose.Font = new System.Drawing.Font("Marlett", 10F);
            this.FlatClose.Location = new System.Drawing.Point(1454, 23);
            this.FlatClose.Margin = new System.Windows.Forms.Padding(6);
            this.FlatClose.Name = "FlatClose";
            this.FlatClose.Size = new System.Drawing.Size(18, 18);
            this.FlatClose.TabIndex = 4;
            this.FlatClose.Text = "Exit";
            this.FlatClose.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1500, 1300);
            this.Controls.Add(this.FormSkin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FlatUI Example";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.FormSkin.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private FlatUI.FormSkin FormSkin;
        private FlatUI.FlatMini FlatMini;
        private FlatUI.FlatClose FlatClose;
        private FlatUI.FlatLabel messageLabel;
        private FlatUI.FlatButton prevButton;
        private FlatUI.FlatButton nextButton;
        private System.Windows.Forms.Panel choicesPanel;
    }
}

