import json
from difflib import SequenceMatcher

import numpy as np

from test import job_list, profile_list


MATCH_THRESHOLD = 0.8

y2 = [
    'AI Singapore',
    'KPMG Singapore',
    'GIC',
    'iDirect Asia Pte',
    'Maybank Singapore',
    'PayPal',
    'iCognitive Pte Singapore',
    'Decision Solutions Pte Ltd',
    'Singapore Computer Systems Limited',
    'Lee Kuan Yew School of Public Policy',
    'EY',
    'CrossTrack Pte Ltd',
    'NVPC - National Volunteer & Philanthropy Centre',
    'Swiss Asia',
    'Deepdive Solutions Pvt Ltd',
    'NEWCLEUS',
    'Cognitive ECM Pte',
    'Hewlett-Packard Singapore',
    'National University of Singapore',
    'Standard Chartered Bank',
    'ASM',
    'KPMG',
    'National University Health System',
    'A*STAR - Agency for Science Technology and Research',
    'Sparkline',
    'HP',
    'Ministry of Defence of Singapore',
    'Etiqa Insurance Pte',
    'J\'D\' Power and Associates',
    'Alibaba',
    'Cognizant',
    'Startup',
    'CrimsonLogic Defense Science Organisation(DSO) Singapore',
    'Uber',
    'NUS Business School',
    'DBS Bank',
    'Panasonic Asia Pacific',
    'AMD',
    'PSA Corporation Limited',
    'IRAS',
    'Infosys Consulting',
    'Razer',
    'Lenovo',
    'Hewlett Packard Enterprise',
    'IBM Global Services',
    'Thales',
    'National University of Singapore',
    'Centre for Maritime Studies NUS',
    'Sompo International',
    'KPMG Singapore',
    'DBS Bank',
    'Vuclip Inc',
    'Temasek Polytechnic',
    'Land Transport Authority (LTA) Singapore',
    'Maybank',
    'ST Electronics',
    'Autodesk',
    'Aon',
    'IHiS (Integrated Health Information Systems)',
    'Gemalto',
    'GovTech Singapore',
    'Islamic Religious Council of Singapore (MUIS)',
    'SINGHOST\'NET',
]

x2 = [
    'Apprentice',
    'Assistant Manager',
    'Associate',
    'Asst Principal Engineer',
    'Business Analyst',
    'Business Analytics Analyst',
    'Business Analytics Developer',
    'Consultant',
    'Consultant',
    'Contract Predictive Analyst',
    'Data & Analytics - Senior Consultant',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst',
    'Data Analyst (consumer analysis part-time)',
    'Data Quality Consultant',
    'Data Science Analyst',
    'Data Scientist',
    'Data Scientist',
    'Data Scientist',
    'Data scientist',
    'Data Scientist - Advanced Analytics',
    'Deputy Head of Department',
    'Development Manager',
    'Director Global Research Services',
    'Senior Fraud Engineer',
    'Enterprise Data Architect|Enterprise Architect Office',
    'Entrepreneur',
    'Functional Consultant',
    'Global Data Analyst',
    'Graduate Research Assistant',
    'IT Analyst',
    'IT Consultant',
    'Member of Technical Staff (MTS) - IT',
    'Operations Planning Analyst',
    'Principal Analyst (Data Analytics)',
    'Principal Consultant',
    'Product Developer (Analytics)',
    'Project Manager',
    'Project Manager',
    'Project Manager',
    'Project Manager',
    'Research Assistant',
    'Research Assistant',
    'Senior Actuary Actuarial and Risk Management',
    'Senior Associate',
    'Senior Business Analyst',
    'Senior Data Analyst',
    'Senior Data Architect',
    'Senior Engineer',
    'Senior Security Engineer',
    'Senior Software Engineer',
    'Senior Software Engineer',
    'Senior Statistical Analyst',
    'Senior System Analyst',
    'Software Engineer',
    'Senior Project Manager',
    'Strategic Policy & Planning Manager',
    'Web Hosting Manager',
]

y1 = [
    'ST Electronics',
    'Defence Science & Technology Agency',
    'Barclays Capital',
    'Bluefish Technologies Group',
    'Barclays Capital',
    'Hewlett Packard Enterprise',
    'Tata Consultancy Services',
    'www\'forthepeople\'net\'in',
    'Medix Multimedia Consultancy Pte Ltd',
    'Ernst and Young (EYC3)',
    'Bank of America Merrill Lynch',
    'Accenture',
    'Cognizant',
    'Tata Consultancy Services',
    'Infosys',
    'Verizon',
    'Saviance Technologies',
    'HCL Technologies',
    'Micron Technology',
    'Samtel Avionics',
    'Amdocs',
    'NCS Group',
    'IBM',
    'Tata Consultancy Services',
    'RBEI',
    'Tata Consultancy Services',
    'Singapore Armed Forces',
    'Great Eastern Life',
    'J\'D\' Power and Associates',
    'China Merchants Bank',
    'BNP Paribas',
    'StarHub',
    'Wipro Technologies',
    'Tata Consultancy Services',
    'Analytics Quotient',
    'Tata Consultancy Services',
    'IBM Global Business Services',
    'AMD',
    'PSA Corporation Limited',
    'Republic of Singapore Navy',
    'Infosys Consulting',
    'Paladion Networks',
    'IBM International Holdings Singapore',
    'Singapore Armed Forces',
    'IBM Global Services',
    'ST Electronics (Info-Software Systems)',
    'Middle Kingdom Group',
    'MindTree Ltd',
    'Guy Carpenter',
    'ST Electronics (Info-Software Systems) Pte Ltd',
    'A*STAR - Agency for Science Technology and Research',
    'ZS Associates',
    'MIMS Pte Ltd',
    'Land Transport Authority (LTA) Singapore',
    'SMRT Corporation Ltd',
    'Combuilder',
    'OBS Financial Solutions Pte',
    'Tata Consultancy Services',
    'IHiS (Integrated Health Information Systems)',
    'Renesas Electronics Corporation',
    'Keppel FELS Ltd',
    'Islamic Religious Council of Singapore (MUIS)',
    'SINGHOSTNET',
]

x1 = [
    'Engineer (Capability Development)',
    'Data Analyst',
    'Graduate Analyst',
    'Senior Software Engineer',
    'Analyst',
    'Business Intelligence/analytics Professional',
    'Systems Engineer',
    'Founder',
    'Technical Consultant',
    'Senior Consultant',
    'Analyst',
    'Software Engineer',
    'Programmer Analyst',
    'IT Analyst',
    'System Engineer',
    'Software Engineer',
    'Network Engineer',
    'Software Engineer - (Business Data Analysis)',
    'Yield Analysis Engineer',
    'Assistant Manager',
    'Subject Matter Expert',
    'Consultant',
    'Business Analyst',
    'System Engineer',
    'Associate Software Engineer',
    'Data Analytics Associate',
    'Senior Engineer',
    'Application Architect',
    'Manager Senior Manager Director Global Research Production',
    'Retail Banking Customer Insight Manager(Junior Executive)',
    'Assistant Vice President',
    'Product Manager',
    'Project Engineer(Business Analyst/QA)',
    'Assistant System Engineer',
    'Business Analyst',
    'System Engineer',
    'Application Developer',
    'Senior IT Engineer',
    'Senior Programmer Analyst',
    'Lead Engineer (Mechanical) for Submarine Systems',
    'Senior Consultant',
    'Associate Consultant',
    'Project Manager',
    'Military Engineering Officer',
    'SAP Consultant',
    'System Specialist',
    'Irish Representative',
    'Programmer Analyst',
    'Vice President GC Analytics',
    'System Specialist',
    'Specialist',
    'Business Analytics Associate',
    'Senior Technical Architect & Lead',
    'Software Engineer',
    'Senior IT Security Analyst',
    'Senior Software Engineer',
    'Software Engineer',
    'Assistant System Engineer',
    'System Analyst',
    'Firmware Engineer',
    'Senior Systems Engineer',
    'Senior Executive Information Systems Planning & Chief Information Office',
    'System Administrator',
]


def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()


def nearest_match(title, v_list):
    last_score = -1
    match_1 = None
    match_2 = None
    for job in v_list:
        similar_metric = similar(title, job)
        if similar_metric > last_score:
            match_2 = match_1
            match_1 = job
            last_score = similar_metric
    return match_1, match_2


def format_salary(salary):
    salary = salary.replace(
        ' ','').replace('range','').replace('about', '').replace('£','').replace(
        ':','').replace(',', '').replace('/mo', '').replace('/yr', '').replace(
        'k','000').replace('$','').replace('€','')
    salary = salary.split('-')
    salary = list(np.float_(salary))
    return np.mean(salary)


def get_salary(profile, job, salary_data, company_title):
    salaries = []
    company_salary = None
    for data in salary_data[1:]:
        salary_range = data['JobInfoStyle__range'].lower()
        try:
            salary = format_salary(salary_range)
        except:
            continue
        title = data['JobInfoStyle__jobTitle']
        if salary >= 40000:
            salary = salary / 12
        elif '/mo' in salary_range:
            salary = salary
        elif '/yr' in salary_range:
            salary = salary / 12
        elif 'JobInfoStyle__meanBasePay' in data and 'mo' in data['JobInfoStyle__meanBasePay']:
            salary = salary
        elif 'hourly' in title.lower().strip():
            salary = salary * 24 * 22
        elif 'JobInfoStyle__meanBasePay' in data and 'yr' in data['JobInfoStyle__meanBasePay']:
            salary = salary / 12

        salaries.append(salary)
        company = data['JobInfoStyle__employerName']
        if similar(company.lower().strip(), company_title.lower().strip()) > MATCH_THRESHOLD:
            company_salary = salary
    min_salary = min(salaries)
    max_salary = max(salaries)
    average_salary = np.mean(salaries)
    median_salary = np.median(salaries)
    if 'average' in salary_data[0]:
        average_salary = salary_data[0]['average'].replace(',','')
        if float(average_salary) >= 40000:
            average_salary = float(average_salary) / 12
    return profile, job, min_salary, max_salary, average_salary, median_salary, company_salary


def look_for_salary_from_job(profile, job, company, location):
    job1, job2 = nearest_match(job, job_list)
    rs = None
    try:
        f1 = 'result/{}_{}.json'.format(location, job1)
        with open(f1) as f:
            salary_data = json.load(f)
            rs = get_salary(profile, job, salary_data, company)
    except Exception as e:
        print(e)
    if rs is None:
        try:
            f2 = 'result/{}_{}.json'.format(location, job2)
            with open(f2) as f:
                salary_data = json.load(f)
                rs = get_salary(profile, job, salary_data, company)
        except Exception as e:
            return (profile, job, None, None, None, None, None)
    return rs


location = 'Singapore'
pre_salary = []
post_salary = []
print(len(x1))
for i in range(len(x1)):
    profile = profile_list[i]
    pre_job = x1[i]
    post_job = x2[i]
    pre_com = y1[i]
    post_com = y2[i]
    pre_salary.append(look_for_salary_from_job(profile, pre_job, pre_com, location))
    post_salary.append(look_for_salary_from_job(profile, post_job, post_com, location))

import csv

out = csv.writer(open("post.csv","w"), delimiter=',')
out.writerow(['profile', 'job', 'min_salary','max_salary', 'average_salary', 'median_salary', 'company_salary'])
for row in post_salary:
    out.writerow(row)

out = csv.writer(open("pre.csv","w"), delimiter=',')
out.writerow(['profile', 'job', 'min_salary','max_salary', 'average_salary', 'median_salary', 'company_salary'])
for row in pre_salary:
    out.writerow(row)
