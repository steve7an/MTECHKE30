import json
import os
import time

from glassdoor.salary import crawl_salary
from util.crawler import get_driver
from test import job_list, company_list, location_list


def main():
    for location in location_list:
        for job in job_list:
            driver = get_driver()
            try:
                result = crawl_salary(driver, location, job)
                if len(result) == 0:
                    continue
            except Exception as e:
                print(e)
                time.sleep(20*60)
                continue
            file_name = 'result/{}_{}.json'.format(location, job)
            with open(file_name, 'w') as f:
                json.dump(result, f)
            time.sleep(20)
            driver.quit()

    for location in location_list:
        for company in company_list:
            driver = get_driver()
            try:
                result = crawl_salary(driver, location, None, company)
                if len(result) == 0:
                    continue
            except Exception as e:
                print(e)
                time.sleep(20*60)
                continue
            file_name = 'result/{}_{}.json'.format(location, company)
            with open(file_name, 'w') as f:
                json.dump(result, f)
            time.sleep(20)
            driver.quit()


if __name__== "__main__":
    main()
