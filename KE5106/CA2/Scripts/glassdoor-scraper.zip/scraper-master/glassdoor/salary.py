"""
    Crawl salary information on glassdoor based on
    job title/company and location
"""
import time

from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys

from util import get_credential, format_text


GLASSDOOR_URL = 'https://www.glassdoor.com'
SALARY_URL = GLASSDOOR_URL + '/Salaries'
LOGIN_URL = GLASSDOOR_URL + '/profile/login_input.htm'
WAIT_SECONDS= 3


def login(driver):
    driver.get(LOGIN_URL)
    username, password = get_credential()
    driver.find_element_by_name('username').send_keys(username)
    element = driver.find_element_by_name('password')
    element.send_keys(password)
    element.submit()


def crawl_salary(driver, location, job_title=None, company=None):
    search_for_company = False
    keyword = job_title
    if job_title is None:
        search_for_company = True
        keyword = company
    print('Start crawling salary for {}-{} in {} from glassdoor'.format(
        job_title, company, location))
    login(driver)
    search(driver, location, keyword)
    if search_for_company:
        salary = get_salary_from_company(driver)
    else:
        salary = get_salary_from_job_title(driver)
    return salary


def search(driver, location, keyword):
    driver.get(SALARY_URL)
    driver.implicitly_wait(WAIT_SECONDS)
    driver.find_element_by_id('KeywordSearch').send_keys(keyword)
    element = driver.find_element_by_id('LocationSearch')
    element.clear()
    element.send_keys(location)
    driver.find_element_by_id("HeroSearchButton").click()
    driver.implicitly_wait(10)
    driver.switch_to_window(driver.window_handles[1])


def get_salary_from_job_title(driver):
    salary_result = []
    average_base = driver.find_elements_by_class_name(
        'OccMedianBasePayStyle__payNumber')
    if len(average_base) > 0:
        salary_result.append({'average': average_base[0].text})
    while True:
        print('Get info from: {}'.format(driver.current_url))
        salary_result = salary_result + parse_salary_info(driver)
        next_button = driver.find_elements_by_class_name(
            'ArrowStyle__nextArrow')
        try:
            print('Crawling the next page...')
            next_button[0].click()
            driver.implicitly_wait(5)
        except:
            print('Completed')
            break
    return salary_result


def get_salary_from_company(driver):
    urls = []
    salary_result = []
    company_list = driver.find_elements_by_class_name('srchSalaryEmployer')
    if len(company_list) > 0:
        for company in company_list:
            count_info = company.find_elements_by_class_name('countInfo')
            link = count_info[0]
            if int(link.text.strip()[0]) == 0:
                # filter out no salary review
                continue
            company_link = company.find_element_by_partial_link_text(
                'Salaries')
            urls.append(company_link.get_attribute('href'))
    for url in urls:
        driver.get(url)
        print('Crawling from: {}'.format(url))
        driver.implicitly_wait(10)
        salary_result = salary_result + parse_salary_info(driver)
    return salary_result


def parse_salary_info(driver):
    salary_result = []
    salary_list = driver.find_elements_by_class_name('salaryList')
    if len(salary_list) > 0:
        soup = BeautifulSoup(salary_list[0].get_attribute('innerHTML'))
        content = soup.find('body')
        salary_info = content.findChildren('div', recursive=False)[1]
        for salary in salary_info.findChildren('div', recursive=False):
            info = {}
            for job_info in salary.select('div[class*="JobInfoStyle"]')[1:]:
                tag_name = job_info.get('class')[0]
                value = format_text(job_info.text)
                info[tag_name] = value

            s_info = salary.select(
                'div[class*="SalaryRowStyle__tightLines"]')[0]
            info['salary'] = format_text(s_info.text)
            salary_result.append(info)
    return salary_result
