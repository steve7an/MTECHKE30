import os


def get_credential():
    username = os.getenv('USER_NAME', 'test')
    password = os.getenv('PASSWORD', 'test')
    return username, password


def format_text(input_string):
    input_string = input_string.strip().replace('\n','')
    input_string = ' '.join(input_string.split())
    return input_string
