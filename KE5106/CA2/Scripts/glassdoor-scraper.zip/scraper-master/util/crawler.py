import os

from selenium import webdriver



BROWSER_OPTS = {
    'chrome': {
        'driver_name': 'chromedriver',
    },
    'firefox': {
        'driver_name': 'geckodriver',
    },
    'default_args': 'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
}


def get_driver():
    driver_path = os.getenv('DRIVER_PATH', os.getcwd())
    browser = os.getenv('BROWSER', 'chrome')
    if browser == 'chrome':
        options = webdriver.ChromeOptions()
        options.add_argument(BROWSER_OPTS['default_args'])
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        return webdriver.Chrome(
            os.path.join(driver_path, BROWSER_OPTS[browser]['driver_name']),
            chrome_options=options
        )

    elif browser == 'firefox':
        pass
    return None
