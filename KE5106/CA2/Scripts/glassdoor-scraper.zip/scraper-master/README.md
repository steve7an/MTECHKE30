# Introduction

# Installation

```sh
make install
```

# How to run


```sh
source .venv/bin/activate
export USER_NAME=your.user.name
export PASSWORD=your.pass.word
export PYTHONPATH=$PYTHONPATH:$PWD

python glassdoor/main.py
```
